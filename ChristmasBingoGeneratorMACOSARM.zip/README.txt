Hi!!!!

I made a Christmas movie bingo generator.
This is the generator.
This one will only work on MacOS. If you
are on Windows, please use the other one.
There are many files in the folder here.
Don't mess with any of them.
The first time you run this, you will have to
right-click the BingoGenerator file inside the folder,
but on subsequent uses, you only have to double click 
the BingoGenerator file for new cards.
The result will be a .jpg in the same folder
called "result.jpg" and is ready to print!
If you want to add new entries to the potential slots, edit bingoset.csv.
Do not include commas in your entries, that will break them.
Do not mess with any of the other files.
I do not know what would happen if you did.

Okay. That is all. Thank you. Enjoy!

-Maddy