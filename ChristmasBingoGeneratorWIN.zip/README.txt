Hi!!!!

I made a Christmas movie bingo generator.
This is the generator.
This one will only work on Windows. If you
are on MacOS, please use the other one.
There are many files in the folder here.
Don't mess with any of them.
To generate a bingo card, double click
BingoGenerator.exe. At first, Windows will scan
it for viruses. This will take ~3 seconds but then
it will run without complication. There
will be no virus scan for subsequent uses.
The result will be a .jpg in the same folder 
called "result.jpg" and is ready to print!
If you want to add new entries to the potential slots, edit bingoset.csv. Just do not use commas, those break it :(
Do not mess with any of the other files.
I do not know what would happen if you did.

Okay. That is all. Thank you. Enjoy!

-Maddy