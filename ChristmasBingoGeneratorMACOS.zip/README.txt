Hi!!!!

I made a Christmas movie bingo generator.
This is the generator.
This one will only work on MacOS. If you
are on Windows, please use the other one.
There are many files in the folder here.
Don't mess with any of them.
To generate a bingo card, double click the BingoGenerator file.
The result will be a .jpg in the same floder
called "result.jpg" and is ready to print!
If you want to add new entries to the potential slots, edit bingoset.csv.
Do not mess with any of the other files.
I do not know what would happen if you did.

Okay. That is all. Thank you. Enjoy!

-Maddy